<?php
/**
 * setup.php — Crea el ÚNICO usuario administrador en MySQL y se auto-elimina.
 *
 * Uso:
 *   1) Crea la base de datos `czstore` en tu servidor MySQL
 *      (phpMyAdmin / consola: CREATE DATABASE czstore;)
 *   2) Verifica que db_config.php tenga los datos correctos (host, db, user, pass).
 *   3) Abre en el navegador:  https://tu-dominio/setup.php
 *   4) Completa usuario + contraseña del admin y pulsa "Crear Administrador".
 *   5) Si todo sale bien, este archivo se BORRA solo del servidor.
 *
 * Medidas de seguridad:
 *   - Contraseña hasheada con PASSWORD_BCRYPT (cost 12).
 *   - Solo permite UN usuario: si ya existe uno, no crea otro.
 *   - Auto-eliminación del archivo con unlink(__FILE__) tras éxito.
 *   - Prepared statements en toda operación SQL.
 */

require_once __DIR__ . '/db_config.php';

$error   = '';
$success = '';
$done    = false;

// Inicializa la tabla si no existe
try {
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS cz_admin_users (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        username VARCHAR(64) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (PDOException $e) {
    $error = 'No se pudo crear la tabla admin: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
}

// Comprueba si ya existe un admin
$alreadyHasAdmin = false;
if (!$error) {
    try {
        $stmt = $pdo->query('SELECT COUNT(*) AS n FROM cz_admin_users');
        $row  = $stmt->fetch();
        if (((int)($row['n'] ?? 0)) > 0) {
            $alreadyHasAdmin = true;
        }
    } catch (PDOException $e) {
        $error = 'No se pudo verificar la tabla admin: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
    }
}

// Procesa el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error && !$alreadyHasAdmin) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm']  ?? '';

    if ($username === '' || $password === '') {
        $error = 'Usuario y contraseña son obligatorios.';
    } elseif (mb_strlen($username) < 3 || mb_strlen($username) > 64) {
        $error = 'El usuario debe tener entre 3 y 64 caracteres.';
    } elseif (strlen($password) < 6) {
        $error = 'La contraseña debe tener al menos 6 caracteres.';
    } elseif ($password !== $confirm) {
        $error = 'Las contraseñas no coinciden.';
    } elseif (!preg_match('/^[A-Za-z0-9_.-]+$/', $username)) {
        $error = 'Usuario: solo letras, números, punto, guion y guion bajo.';
    } else {
        try {
            $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
            $stmt = $pdo->prepare('INSERT INTO cz_admin_users (username, password_hash) VALUES (:u, :h)');
            $stmt->bindValue(':u', $username, PDO::PARAM_STR);
            $stmt->bindValue(':h', $hash,  PDO::PARAM_STR);
            $stmt->execute();

            $success = 'Usuario administrador "' . htmlspecialchars($username, ENT_QUOTES, 'UTF-8') . '" creado correctamente. Este archivo se eliminará automáticamente.';
            $done = true;

            // Auto-eliminación del propio setup.php
            @unlink(__FILE__);
        } catch (PDOException $e) {
            $error = 'Error al insertar el admin: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es" class="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CZSTORE · Setup Admin</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    body { background:#0a0a0a; }
    .gold { color:#d4af37; }
    .gold-bg { background:#d4af37; }
</style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">

<div class="w-full max-w-md bg-zinc-900 border border-zinc-700 rounded-2xl p-7 shadow-2xl">
    <div class="text-center mb-6">
        <div class="inline-flex items-center justify-center w-12 h-12 rounded-full bg-zinc-800 border border-yellow-600/40 mb-3">
            <span class="gold text-xl font-bold">CZ</span>
        </div>
        <h1 class="text-xl font-bold text-white">Creación del Administrador</h1>
        <p class="text-xs text-zinc-400 mt-1">Paso único · luego este archivo se borrará</p>
    </div>

    <?php if ($done): ?>
        <div class="bg-green-900/40 border border-green-600/50 text-green-300 text-sm rounded-lg p-4 mb-4">
            <strong>Éxito:</strong> <?= $success ?>
        </div>
        <p class="text-xs text-zinc-400 text-center">
            setup.php se ha eliminado del servidor.<br>
            Si por algún motivo sigue visible, bórralo manualmente por FTP.
        </p>
        <a href="index.php" class="block text-center mt-5 gold-bg text-black font-bold py-2.5 rounded-xl text-sm hover:bg-yellow-500 transition">Ir a la tienda</a>

    <?php elseif ($alreadyHasAdmin): ?>
        <div class="bg-red-900/40 border border-red-600/50 text-red-300 text-sm rounded-lg p-4 mb-4">
            <strong>Bloqueado:</strong> ya existe un usuario administrador en la base de datos.
            Esta página debe usarse una sola vez. Si necesitas recrear el admin,
            borra la fila existente desde phpMyAdmin y vuelve a subir setup.php.
        </div>
        <a href="index.php" class="block text-center mt-5 gold-bg text-black font-bold py-2.5 rounded-xl text-sm hover:bg-yellow-500 transition">Ir a la tienda</a>

    <?php else: ?>

        <?php if ($error): ?>
            <div class="bg-red-900/40 border border-red-600/50 text-red-300 text-sm rounded-lg p-3 mb-4">
                <?= $error ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-[11px] font-bold text-zinc-400 uppercase mb-1">Usuario Admin</label>
                <input type="text" name="username" required minlength="3" maxlength="64"
                    pattern="[A-Za-z0-9_.\-]+"
                    value="<?= htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                    placeholder="ej: admin"
                    class="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:border-yellow-500">
            </div>
            <div>
                <label class="block text-[11px] font-bold text-zinc-400 uppercase mb-1">Contraseña</label>
                <input type="password" name="password" required minlength="6"
                    placeholder="mínimo 6 caracteres"
                    class="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:border-yellow-500">
            </div>
            <div>
                <label class="block text-[11px] font-bold text-zinc-400 uppercase mb-1">Repetir Contraseña</label>
                <input type="password" name="confirm" required minlength="6"
                    placeholder="repetir"
                    class="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:border-yellow-500">
            </div>

            <button type="submit"
                class="w-full gold-bg text-black font-bold py-3 rounded-xl text-sm hover:bg-yellow-500 transition">
                Crear Administrador
            </button>
        </form>

        <p class="text-[11px] text-zinc-500 mt-4 text-center">
            La contraseña se guardará hasheada con bcrypt.<br>
            Nadie podrá verla, ni siquiera tú.
        </p>
    <?php endif; ?>
</div>

</body>
</html>
