<?php
/**
 * db_config.php
 * Configuración de conexión MySQL y utilidades de sesión admin seguras.
 * - Usa PDO con prepared statements (anti-inyección SQL).
 * - Contraseñas hasheadas con PASSWORD_BCRYPT.
 * - Sesión PHP con cookie HttpOnly + SameSite y expiración configurable.
 *
 * SOLO un usuario administrador debe existir en la tabla `cz_admin_users`.
 * Ese usuario se crea con /setup.php (que luego se auto-elimina).
 */

// ====== CONFIGURACIÓN MYSQL (EDITA SI NECESARIO) ======
define('DB_HOST', 'localhost');   // MySQL Host Name
define('DB_NAME', 'czstore');      // MySQL DB Name
define('DB_USER', 'root');         // MySQL User Name
define('DB_PASS', '');             // MySQL Password (vacío)
define('DB_CHARSET', 'utf8mb4');

// ====== CONFIGURACIÓN DE SESIÓN ADMIN ======
define('ADMIN_SESSION_LIFETIME', 3600); // 1 hora de inactividad (segundos)

/**
 * Devuelve una instancia PDO única (singleton) con modo excepción.
 * Lanza excepción si la conexión falla (no revela credenciales en pantalla).
 */
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false, // prepared statements REALES
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos']);
            exit;
        }
    }
    return $pdo;
}

/**
 * Inicia la sesión PHP de forma segura (HttpOnly, SameSite=Lax, lifetime configurable).
 * Debe llamarse ANTES de cualquier output.
 */
function startSecureSession(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;

    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['SERVER_PORT'] ?? 0) == 443);

    session_set_cookie_params([
        'lifetime' => ADMIN_SESSION_LIFETIME,
        'path'     => '/',
        'httponly' => true,
        'secure'   => $https,
        'samesite' => 'Lax',
    ]);
    ini_set('session.gc_maxlifetime', ADMIN_SESSION_LIFETIME);
    session_start();

    // Control de expiración por inactividad
    $now = time();
    if (!empty($_SESSION['admin_last_activity'])
        && ($now - $_SESSION['admin_last_activity']) > ADMIN_SESSION_LIFETIME) {
        // Sesión expirada por inactividad: destruir
        $_SESSION = [];
        session_destroy();
        session_start();
    }
    $_SESSION['admin_last_activity'] = $now;
}

/**
 * Verifica credenciales admin contra MySQL con prepared statement.
 * Compara el hash bcrypt (timing-safe vía password_verify).
 *
 * @return bool true si las credenciales son válidas
 */
function validateAdminCredentials(string $username, string $password): bool {
    if ($username === '' || $password === '') return false;

    try {
        $stmt = db()->prepare('SELECT password_hash FROM cz_admin_users WHERE username = :u LIMIT 1');
        $stmt->bindValue(':u', $username, PDO::PARAM_STR);
        $stmt->execute();
        $row = $stmt->fetch();
    } catch (PDOException $e) {
        return false;
    }

    if (!$row || empty($row['password_hash'])) return false;
    return password_verify($password, $row['password_hash']);
}

/**
 * ¿Hay una sesión admin activa y válida?
 */
function isAdminSessionValid(): bool {
    return !empty($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

/**
 * Marca la sesión como autenticada (llamar tras validar credenciales).
 */
function createAdminSession(string $username): void {
    session_regenerate_id(true); // prevenir fixation
    $_SESSION['admin_logged_in']      = true;
    $_SESSION['admin_username']       = $username;
    $_SESSION['admin_last_activity']  = time();
}

/**
 * Cierra sesión admin (destruye datos pero mantiene la cookie de sesión limpia).
 */
function destroyAdminSession(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'] ?? '', $p['secure'], $p['httponly']);
    }
    session_destroy();
}
