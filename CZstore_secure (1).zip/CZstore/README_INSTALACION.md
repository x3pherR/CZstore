# CZSTORE · Login Admin con MySQL (seguro)

Esta versión reemplaza el login admin basado en `users.json` (texto plano) por un sistema seguro con **MySQL + PDO prepared statements + sesiones PHP**.

## Archivos

| Archivo | Descripción |
|---|---|
| `index.php` | Tienda + panel admin. **Modificado** para usar MySQL/sesiones. |
| `product.php` | Página de detalle del producto. **Sin cambios**. |
| `db_config.php` | **NUEVO**. Configuración MySQL y utilidades de sesión. |
| `setup.php` | **NUEVO**. Página única para crear el admin. Se auto-elimina. |
| `users.json` | **ELIMINADO**. Ya no se usa ni se crea. |

## Instalación (3 pasos)

### 1) Crea la base de datos MySQL

En tu phpMyAdmin o consola MySQL ejecuta:

```sql
CREATE DATABASE czstore CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

*(Si le pones otro nombre, edita `db_config.php` y cambia `DB_NAME`.)*

### 2) Edita `db_config.php` si tus credenciales difieren

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'czstore');
define('DB_USER', 'root');
define('DB_PASS', '');             // contraseña MySQL (vacía en XAMPP/local)
```

### 3) Sube todos los archivos a tu hosting y abre `setup.php`

```
https://tu-dominio.com/setup.php
```

Completa el formulario con el usuario y contraseña admin que quieras.
La contraseña se guarda **hasheada con bcrypt** (nadie puede verla, ni tú).
Al terminar, `setup.php` **se borra solo** del servidor.

## Cómo funciona la seguridad

| Antes | Ahora |
|---|---|
| Contraseña en `users.json` en texto plano | Contraseña en MySQL hasheada con `PASSWORD_BCRYPT` cost 12 |
| Usuario+contraseña reenviados en CADA petición AJAX | Solo se envían al hacer login; luego se valida la sesión PHP vía cookie |
| Contraseña guardada en `sessionStorage` del navegador | **Nada** se guarda en el navegador; la cookie `PHPSESSID` es `HttpOnly` + `SameSite=Lax` |
| Login abre automáticamente el panel admin | Tras login **NO** se abre el panel; el usuario debe pulsar "Admin" de nuevo |
| Sin protección anti-inyección SQL | Consultas con PDO `prepare()` + `bindValue()` (prepared statements reales) |

## Duración de la sesión

Por defecto la sesión admin caduca tras **1 hora (3600 s)** de inactividad.
Para cambiarlo, edita `db_config.php`:

```php
define('ADMIN_SESSION_LIFETIME', 3600); // segundos
```

## Eliminar `setup.php` manualmente

Si por algún motivo la auto-eliminación fallara (permisos de escritura),
borra `setup.php` por FTP/manualmente tras crear el admin.

## Estructura de la tabla MySQL

```sql
CREATE TABLE cz_admin_users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username VARCHAR(64) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

`setup.php` la crea automáticamente; no necesitas ejecutar SQL a mano.

## Cambiar la contraseña del admin

1. Entra a phpMyAdmin.
2. Ejecuta: `DELETE FROM cz_admin_users;`
3. Vuelve a subir `setup.php` y crea el admin de nuevo.

## Notas

- Solo puede existir **UN** usuario admin (impuesto por `setup.php`).
- La página de la tienda (`index.php`) y `product.php` mantienen toda la funcionalidad original.
- Si la sesión expira mientras editas, recibirás un toast "Sesión expirada" y deberás iniciar sesión de nuevo.
